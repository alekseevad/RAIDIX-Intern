#include <iostream>

int main()
{
    std::cout << "Test task in RADIX that was patched" << std::endl;
    return 0;
}
