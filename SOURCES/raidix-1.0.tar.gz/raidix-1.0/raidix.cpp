#include <iostream>

int main()
{
    std::cout << "Test task in RADIX" << std::endl;
    return 0;
}
